from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.generic import TemplateView
import json


# Create your views here.

class HomePageView(TemplateView):
    template_name = 'index.html'


class RetailerPageView(TemplateView):
    template_name = 'register-retailer.html'


# Database

from django.shortcuts import render
from mysite.models import retailer_registration, customer_ordering, customer_info
import pandas as pd


# Create your views here.

def customer(request):
    shops = retailer_registration.objects.all()
    print(shops)
    return render(request, 'customer.html', {"shops": shops})


def enter_retailer(request):
    shopName = request.POST['shopname']
    area = request.POST['area']
    ingredients = request.POST['ingredients']
    list_ingredients = ingredients.split(',')
    starttime = request.POST['starttime']
    endtime = request.POST['endtime']
    int_start = int(starttime.split(':')[0])
    int_end = int(endtime.split(':')[0])
    timezone = {}
    for i in range(int_start, int_end):
        timezone[str(i) + ':00' + ':' + str(i + 1) + ':00'] = 0
    enter_retailer = retailer_registration(shopname=shopName, areaname=area, ingredients=list_ingredients,
                                           timeslots=timezone)
    enter_retailer.save()
    return render(request, 'index.html')


def order(request):
    timeslot = request.GET['time']
    shopname = request.GET['shopname']
    return render(request, 'AddOrder.html', {"timeslot": timeslot, "shopname": shopname})


def final_orders(request):
    name = request.POST['name']
    order = request.POST['order']
    timeslot = request.POST['time']
    shopname = request.POST['shopname']
    place_order = customer_ordering(customerName=name, notes=order, timeslots=timeslot, shopName=shopname)
    place_order.save()

    get_name = retailer_registration.objects.get(shopname=shopname)
    get_name.timeslots[timeslot] += 1
    get_name.save()

    temp = customer_ordering.objects.all()

    customer_track = customer_info.objects.get(username=name)
    orderlist = order.split(',')
    df = pd.read_csv('nutrition.csv')
    for i in orderlist:
        val = df[df['Name'] == i]
        customer_track.vitaminA += int(val.Vitamin_A)
        customer_track.vitaminC += int(val.Vitamin_C)
        customer_track.iron += int(val.iron)
        customer_track.carbohydrate += int(val.carbohydrate)
        customer_track.cholestrol += int(val.cholestrol)
    customer_track.save()

    return render(request, 'qrcodereader/index.html', {'id': str(len(temp))})


def choice_retailer(request):
    return render(request, 'choice_retailer.html')


def entershop(request):
    return render(request, 'entershop.html')


def dashboard(request):
    shopname = request.POST['shopname']
    customers = customer_ordering.objects.all()
    hashmap = {}
    for i in customers:
        cust_orders = i.notes
        cust_orders_list = cust_orders.split(',')
        for j in cust_orders_list:
            try:
                hashmap[j] += 1
            except:
                hashmap[j] = 1

    return render(request, 'dash.html', {'stock': hashmap, 'shopname': shopname})


@csrf_exempt
def getOrderData(request):
    orderId = request.POST['orderId']
    orderData = customer_ordering.objects.get(customerID=orderId)
    print(orderData.customerName)
    print(orderData.notes)
    response = {'customer': orderData.customerName, 'notes': orderData.notes}
    return JsonResponse(response)


@csrf_exempt
def filterout(request):
    query = request.GET['search']
    shops = retailer_registration.objects.all()
    answer = []
    for i in shops:
        if (query in i.ingredients):
            answer.append(i)
        else:
            continue

    return render(request, 'customer.html', {"shops": answer})


@csrf_exempt
def createuser(request):
    username = request.POST['username']
    password = request.POST['password']
    area = request.POST['area']
    customer_create = customer_info(username=username, password=password, area=area)
    customer_create.save()
    shops = retailer_registration.objects.all()
    return render(request, 'customer.html', {"shops": shops})


def customerdash(request):
    username = request.POST['customerid']
    nutrition = {}
    data = customer_info.objects.get(username=username)
    nutrition["Vitamin_A"] = data.vitaminA
    nutrition["Vitamin_C"] = data.vitaminC
    nutrition["iron"] = data.iron
    nutrition["carbohydrate"] = data.carbohydrate
    nutrition["cholestrol"] = data.cholestrol

    min_key = "Vitamin_A"
    min_val = data.vitaminA
    for key, value in nutrition.items():
        if value < min_val:
            min_key = key
            min_val = value

    items = find_sources(min_key)

    return render(request, 'customerdashboard.html',
                  {"dict": nutrition, "customername": username, "min_key": min_key, "items":items})


def find_sources(nutrtion):
    dataFrame = pd.read_csv("nutrition.csv")
    try:
        return list(dataFrame.sort_values(nutrtion, ascending=False)["Name"][0:10].values)
    except:
        return "Nutrtion Does Not Found"


def displaycustomer(request):
    shopname = request.GET['cust_shop']
    all_customers = customer_ordering.objects.all()
    all_info = customer_info.objects.all()
    customer_area = {}
    for i in all_customers:
        temp = i.customerName
        shop = i.shopName
        if (shop == shopname):
            try:
                customer_area[all_info.get(username=temp).area] += 1
            except:
                customer_area[all_info.get(username=temp).area] = 1

    return render(request, 'displaycustomer.html', {"customer_area": customer_area, "shopname": shopname})
