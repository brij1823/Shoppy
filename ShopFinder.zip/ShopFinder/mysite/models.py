from django.db import models
from django_mysql.models import ListCharField
from jsonfield import JSONField

class retailer_registration(models.Model):
	shopname = models.CharField(max_length = 100)
	areaname = models.CharField(max_length = 500)
	timeslots =JSONField()

	ingredients = ListCharField(
        base_field=models.CharField(max_length=10),
        size=6,
        max_length=(6 * 11)  # 6 * 10 character nominals, plus commas
    )

class customer_ordering(models.Model):
	customerID = models.IntegerField(primary_key = True)
	customerName = models.CharField(max_length=500)
	notes=models.CharField(max_length=1000)
	timeslots =  models.CharField(max_length=20)
	shopName=models.CharField(max_length=100,default = "")

class customer_info(models.Model):
	username = models.CharField(max_length=100)
	password=models.CharField(max_length=100)
	area = models.CharField(max_length=100,default='')
	vitaminA = models.IntegerField(default=0)
	vitaminC = models.IntegerField(default=0)
	iron = models.IntegerField(default=0)
	carbohydrate = models.IntegerField(default=0)
	cholestrol = models.IntegerField(default=0)
	