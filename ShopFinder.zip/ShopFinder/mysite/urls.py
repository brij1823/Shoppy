"""ResearchDataExtract URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.assets, name='assets')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='assets')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from .views import *

urlpatterns = [
    path('', HomePageView.as_view()),
    path('retailer', RetailerPageView.as_view()),
    path('customer', customer),
    path('enter_retailer', enter_retailer),

    # path('customer', views.customer),
    # path('enter_retailer', views.enter_retailer),
    path('order', order),
    path('final_orders', final_orders),
    # path('choice_retailer', views.choice_retailer),
    # path('entershop', views.entershop),
    path('dashboard', dashboard),
    path('getOrderData', getOrderData),
    path('filterout',filterout),
    path('createuser',createuser),
    path('customerdash',customerdash),
    path('displaycustomer',displaycustomer),

]
