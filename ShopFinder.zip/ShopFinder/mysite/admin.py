from django.contrib import admin
from mysite.models import retailer_registration,customer_ordering,customer_info

admin.site.register(retailer_registration)
admin.site.register(customer_ordering)
admin.site.register(customer_info)